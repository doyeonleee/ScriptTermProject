from distutils.core import setup

setup(name='TermProject',
      version='1.0',
      py_modules=['func','gmail','launcher','mysmtplib','xmlfunc']
      )
